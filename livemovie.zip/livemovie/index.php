<html>

<head>
    <link rel="stylesheet" type ="text/css" href="index.css">
</head>

<body>

<h1>Click One of Two Options</h1>

<h2>Insert </h2>
<button class="btn btn-primary" onclick="window.location.href='movie.php'; " >Insert Into Movie </button>

<h2>Show  Information</h2>
<button class="btn btn-primary" onclick="window.location.href='showmovie.php';"> Show Movie Information</button>
</body>

</html>